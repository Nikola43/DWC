import { Vet } from './vet';

describe('Vet', () => {
  it('should create an instance', () => {
    expect(new Vet()).toBeTruthy();
  });
});
