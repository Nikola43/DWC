import { Pettype } from './pettype';

describe('Pettype', () => {
  it('should create an instance', () => {
    expect(new Pettype()).toBeTruthy();
  });
});
