export class Visit {
  id: number;
  pet_id: number;
  visit_date: Date;
  description: string;
}
