export class Vet {
  id: number;
  firstName: string;
  lastName: string;
}
