export class Pettype {
  id: number;
  name: string;
}
